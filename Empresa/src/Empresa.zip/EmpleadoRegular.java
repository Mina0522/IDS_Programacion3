
public class EmpleadoRegular extends Empleado {

    public EmpleadoRegular(int id_empleado, String nombre, String apellidos, String puesto, double salario) {
        super(id_empleado, nombre, apellidos, puesto, salario);
    }

}
