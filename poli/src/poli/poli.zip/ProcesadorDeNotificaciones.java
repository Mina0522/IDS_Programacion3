package poli;

public class ProcesadorDeNotificaciones {

    public static void procesarNotificacion(Notificacion notificacion) {
        notificacion.enviar();
    }
}
